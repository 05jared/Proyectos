const API_URL = 'https://api-pacientes-uthh.vercel.app/api';

let indiceActual = 0;
let noticias = [];

async function cargarNoticias() {
  try {
    const response = await fetch(`${API_URL}/noticias`);
    noticias = await response.json();
    renderCarrusel();
    renderIndicadores();
  } catch (error) {
    console.error('Error al cargar noticias:', error);
  }
}

function renderCarrusel() {
  const track = document.getElementById('carrusel-track');
  track.innerHTML = '';

  noticias.forEach((noticia) => {
    const card = document.createElement('div');
    card.classList.add('noticia-card');
    card.innerHTML = `
      <img src="${noticia.imagen || 'img/default.jpg'}" alt="${noticia.titulo}">
      <h3>${noticia.titulo}</h3>
      <p>${noticia.descripcion}</p>
    `;
    track.appendChild(card);
  });

  actualizarPosicion();
}

function renderIndicadores() {
  const indicadores = document.getElementById('indicadores');
  indicadores.innerHTML = '';

  noticias.forEach((_, i) => {
    const punto = document.createElement('span');
    punto.classList.add('indicador');
    if (i === 0) punto.classList.add('activo');
    punto.onclick = () => irA(i);
    indicadores.appendChild(punto);
  });
}

function actualizarPosicion() {
  const track = document.getElementById('carrusel-track');
  track.style.transform = `translateX(-${indiceActual * 100}%)`;

  document.querySelectorAll('.indicador').forEach((p, i) => {
    p.classList.toggle('activo', i === indiceActual);
  });
}

function moverCarrusel(direccion) {
  indiceActual = (indiceActual + direccion + noticias.length) % noticias.length;
  actualizarPosicion();
}

function irA(index) {
  indiceActual = index;
  actualizarPosicion();
}

cargarNoticias();   