const API_URL = 'https://api-pacientes-uthh.vercel.app/api';

/* ── NAVBAR ── */
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 20);
}, { passive: true });

/* ── HAMBURGUESA ── */
const btnH = document.getElementById('btn-hamburguesa');
const menuM = document.getElementById('menu-movil');

btnH.addEventListener('click', () => {
  const ab = menuM.classList.toggle('abierto');
  btnH.classList.toggle('abierto', ab);
});

menuM.querySelectorAll('a').forEach(a =>
  a.addEventListener('click', () => {
    menuM.classList.remove('abierto');
    btnH.classList.remove('abierto');
  })
);

document.addEventListener('click', (e) => {
  if (!btnH.contains(e.target) && !menuM.contains(e.target)) {
    menuM.classList.remove('abierto');
    btnH.classList.remove('abierto');
  }
});

/* ── CARRUSEL ── */
let indiceActual = 0;
let noticias = [];

async function cargarNoticias() {
  try {
    const response = await fetch(`${API_URL}/noticias`);
    noticias = await response.json();
    renderCarrusel();
    renderIndicadores();
  } catch (error) {
    console.error('Error al cargar noticias:', error);
  }
}

function renderCarrusel() {
  const track = document.getElementById('carrusel-track');
  track.innerHTML = '';

  noticias.forEach((noticia) => {
    const card = document.createElement('div');
    card.classList.add('noticia-card');
    card.innerHTML = `
      <img src="${noticia.imagen || 'img/default.jpg'}" alt="${noticia.titulo}">
      <span class="noticia-categoria">${noticia.categoria || 'Aviso'}</span>
      <h3>${noticia.titulo}</h3>
      <p>${noticia.descripcion}</p>
    `;
    track.appendChild(card);
  });

  actualizarPosicion();
}
function renderIndicadores() {
  const indicadores = document.getElementById('indicadores');
  indicadores.innerHTML = '';

  noticias.forEach((_, i) => {
    const punto = document.createElement('span');
    punto.classList.add('indicador');
    if (i === 0) punto.classList.add('activo');
    punto.onclick = () => irA(i);
    indicadores.appendChild(punto);
  });
}

function actualizarPosicion() {
  const track = document.getElementById('carrusel-track');
  const cards = track.querySelectorAll('.noticia-card');
  if (!cards.length) return;

  const cardWidth = cards[0].offsetWidth + 24; // 24 = gap
  track.style.transform = `translateX(-${indiceActual * cardWidth}px)`;

  document.querySelectorAll('.indicador').forEach((p, i) => {
    p.classList.toggle('activo', i === indiceActual);
  });
}

function moverCarrusel(direccion) {
  const track = document.getElementById('carrusel-track');
  const cards = track.querySelectorAll('.noticia-card');
  if (!cards.length) return;

  const maxIndice = Math.max(0, noticias.length - 3); // 3 visibles en desktop
  indiceActual = Math.min(Math.max(indiceActual + direccion, 0), maxIndice);
  actualizarPosicion();
}

function irA(index) {
  indiceActual = index;
  actualizarPosicion();
}

cargarNoticias();